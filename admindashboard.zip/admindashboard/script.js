let body= document.getElementById("body");
body.addEventListener('click' , function hellow(){
     return "hello there";
})
console.log(hellow);